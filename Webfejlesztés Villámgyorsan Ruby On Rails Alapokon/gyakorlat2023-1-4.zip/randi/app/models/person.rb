class Person < ApplicationRecord
  belongs_to :user
  has_many :comments
  has_many :users, through: :comments

  before_save :a
  enum gender: [:male, :female]
  scope :is_male, -> { where(gender: 0) }

  def a
  end
end
