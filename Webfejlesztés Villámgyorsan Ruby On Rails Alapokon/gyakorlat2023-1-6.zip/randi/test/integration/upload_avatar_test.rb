require "test_helper"

class UploadAvatarTest < ActionDispatch::IntegrationTest
  def setup
    @valaki = users(:valaki)
  end

  test "logout" do
    get url_for(controller: 'say', action: 'hello')
    assert_nil session[:user]
    assert_response :success
    assert_select 'legend', "Login"

    post url_for(controller: 'sessions', action: 'create'), params: { email: users(:valaki).email, password: 'titok' }, headers: { 'HTTP_REFERER': '/say/hello' }
    assert_response :redirect
    follow_redirect!
    assert_equal session[:user], users(:valaki).id
    assert_select "a", "Profile"

    get edit_person_path(users(:valaki).person.id)
    assert_response :success
    assert_select "label", "Uploaded image"

    assert_nil users(:valaki).person.attachment
    upload_file = fixture_file_upload('test/fixtures/files/rails_form.png', 'image/png')
    patch person_path(users(:valaki).person.id), params: { person: {uploaded_image: upload_file} }, headers: { 'HTTP_REFERER': person_path(users(:valaki).person.id) }
    assert_response :redirect
    assert_equal Attachment.all.size, 1
    assert File.exists? "public/data/"+users(:valaki).person.id.to_s
    follow_redirect!
    assert_select 'a', 'Logout'

    get logout_path
    assert_nil session[:user]
    assert_response :redirect
    follow_redirect!
    assert_select "legend", "Login"
  end
end
