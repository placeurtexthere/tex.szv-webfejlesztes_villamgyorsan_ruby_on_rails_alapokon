module ApplicationHelper
  def logged_in?
    false
  end
end
