class UsersController < ApplicationController
  def new
    @user = User.new
  end

  def edit
    @user = User.new username: 'Valaki', email: 'valaki@mail.bme.hu'
  end

  def forgotten
  end
end
