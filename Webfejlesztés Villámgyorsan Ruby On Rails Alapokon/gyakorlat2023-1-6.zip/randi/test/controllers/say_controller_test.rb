require "test_helper"

class SayControllerTest < ActionDispatch::IntegrationTest
  test "should get hello" do
    get url_for(controller: 'say', action: 'hello')
    assert_response :success
    assert_select 'legend', 'Login'
    assert_nil session[:user]
  end
end
