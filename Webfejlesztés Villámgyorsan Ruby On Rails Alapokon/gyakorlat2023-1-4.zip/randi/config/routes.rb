Rails.application.routes.draw do
  post 'sessions/create', to: 'sessions#create', as: 'login'
  match 'sessions/destroy', to: 'sessions#destroy', via: [:delete, :get], as: 'logout'
#  match ':controller/:action.:format', via: [:get, :post, :put, :patch, :delete]
  get 'users/new', to: 'users#new', as: 'new'
  post 'users/create', to: 'users#create', as: 'register' 
  get 'users/edit/:id', to: 'users#edit', as: 'edit_profile', default: { hello: 'hello'}
  put 'users/update/:id', to: 'users#update', as: 'update_profile'
  get 'users/forgotten'
  post 'users/send_forgotten', to: 'users#send_forgotten'
  resources :people
  get 'say/hello', to: 'say#hello', as: 'hello'
  # Define your application routes per the DSL in https://guides.rubyonrails.org/routing.html

  # Defines the root path route ("/")
  # root "articles#index"
end
