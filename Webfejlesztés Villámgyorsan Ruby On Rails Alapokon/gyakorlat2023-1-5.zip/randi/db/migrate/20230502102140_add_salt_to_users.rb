class AddSaltToUsers < ActiveRecord::Migration[7.0]
  def change
    add_column :users, :salt, :string
    rename_column :users, :password, :encrypted_password
  end
end
