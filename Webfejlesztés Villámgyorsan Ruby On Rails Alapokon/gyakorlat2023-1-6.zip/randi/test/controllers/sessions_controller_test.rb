require "test_helper"

class SessionsControllerTest < ActionDispatch::IntegrationTest
  test "login" do
    get url_for(controller: 'say', action: 'hello')
    assert_nil session[:user]
    assert_response :success
    assert_select 'legend', "Login"

    post url_for(controller: 'sessions', action: 'create'), params: { email: users(:valaki).email, password: 'titok' }, headers: { 'HTTP_REFERER': '/say/hello' }
    assert_response :redirect
    follow_redirect!
    assert_equal session[:user], users(:valaki).id
    assert_select "a", "Profile"
    # post login_path
  end
  
  test "invalid login" do
    get url_for(controller: 'say', action: 'hello')
    assert_nil session[:user]
    assert_response :success
    assert_select 'legend', "Login"

    post url_for(controller: 'sessions', action: 'create'), params: { email: users(:valaki).email, password: 'titok2' }, headers: { 'HTTP_REFERER': '/say/hello' }
    assert_response :redirect
    follow_redirect!
    assert_nil session[:user]
    assert_select "legend", "Login"
    # post login_path
  end
  
  test "logout" do
    get url_for(controller: 'say', action: 'hello')
    assert_nil session[:user]
    assert_response :success
    assert_select 'legend', "Login"

    post url_for(controller: 'sessions', action: 'create'), params: { email: users(:valaki).email, password: 'titok' }, headers: { 'HTTP_REFERER': '/say/hello' }
    assert_response :redirect
    follow_redirect!
    assert_equal session[:user], users(:valaki).id
    assert_select "a", "Profile"

    get logout_path
    assert_nil session[:user]
    assert_response :redirect
    follow_redirect!
    assert_select "legend", "Login"
  end
end
