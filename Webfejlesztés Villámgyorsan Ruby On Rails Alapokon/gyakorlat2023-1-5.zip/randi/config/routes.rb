Rails.application.routes.draw do
  post 'sessions/create', to: 'sessions#create', as: 'login'
  match 'sessions/destroy', to: 'sessions#destroy', via: [:delete, :get], as: 'logout'
#  match ':controller/:action.:format', via: [:get, :post, :put, :patch, :delete]
  get 'users/new', to: 'users#new', as: 'new'
  post 'users/create', to: 'users#create', as: 'register' 
  get 'users/edit/:id', to: 'users#edit', as: 'edit_profile', default: { hello: 'hello'}
  put 'users/update/:id', to: 'users#update', as: 'update_profile'
  get 'users/forgotten', to: 'users#forgotten', as: 'forgotten'
  post 'users/send_forgotten', to: 'users#send_forgotten', as: 'send_forgotten'
  resources :people do
    get 'page/:page', on: :collection, to: 'people#index', as: 'page'
    get 'download', on: :member, to: 'people#download', as: 'download'
    get 'add_friend', on: :member, to: 'people#add_friend', as: 'add_friend'
    get 'remove_friend', on: :member, to: 'people#remove_friend', as: 'remove_friend'
  end
  get 'say/hello', to: 'say#hello', as: 'hello'
  # Define your application routes per the DSL in https://guides.rubyonrails.org/routing.html

  # Defines the root path route ("/")
  root "say#hello"
end
