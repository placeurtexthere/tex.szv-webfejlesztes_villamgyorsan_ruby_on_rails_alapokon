class Attachment < ApplicationRecord
  belongs_to :person

  def self.save_file(upload, p)
    return if upload.nil?
    dir = Rails.root.join('public', 'data')
    unless File.exists? dir
      Dir.mkdir dir
    end
    fname = upload.original_filename
    a = Attachment.new name: fname, mime: upload.content_type, person: p
    a.save
    path = File.join(dir, p.id.to_s)
    File.open(path, 'wb') do |f| f.write(upload.read) end
    a.update path: path, size: File.size(path)
  end
end
