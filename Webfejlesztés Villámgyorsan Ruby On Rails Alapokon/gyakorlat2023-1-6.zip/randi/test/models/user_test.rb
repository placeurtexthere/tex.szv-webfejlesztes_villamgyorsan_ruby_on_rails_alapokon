require "test_helper"

class UserTest < ActiveSupport::TestCase
  # def test_the_truth
  test "the truth" do
    assert true
  end

  test "cannot save user without username" do
    u = User.new email: 'valaki@mail.bme.hu'
    assert !u.save, "Houston, we have a problem"
  end

  test "cannot save user without email" do
    u = User.new username: 'valaki'
    assert !u.save, "Houston, we have a problem"
  end

  test "cannot save user with existing email address" do
    u = User.new username: users(:valaki).username, email: users(:valaki).email
    assert !u.save
  end
end
