class Person < ApplicationRecord
  attr_accessor :uploaded_image

  belongs_to :user
  has_many :comments
  has_many :users, through: :comments
  has_one :attachment

  before_save :a
  enum gender: {:male => false, :female => true }
  scope :is_male, -> { where(gender: 0) }

  def a
    Attachment.save_file self.uploaded_image, self
  end

  def Person.get_page(page)
    Person.all.paginate(page: page, per_page: 2)
  end
end
