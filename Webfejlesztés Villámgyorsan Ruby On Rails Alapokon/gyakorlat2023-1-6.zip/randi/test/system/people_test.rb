require "application_system_test_case"

class PeopleTest < ApplicationSystemTestCase
  driven_by :selenium, using: :firefox, screen_size: [1400, 1400]

  setup do
    @person = people(:valaki)
  end

  test "login" do
    visit hello_path # '/say/hello'
    assert_selector "legend", text: "Login"

    fill_in "Email", with: @person.user.email
    fill_in "Password", with: "titok"
    click_on "Login"

    assert_selector 'a', text: "Logout"
  end
end
