class SayController < ApplicationController
  #layout 'main'
  def hello
    @time = Time.now
  end
end
